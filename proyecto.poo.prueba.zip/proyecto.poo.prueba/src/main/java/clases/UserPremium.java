package clases;

public class UserPremium extends Usuario{
	
	public static void reservarVehiculo() {
		
	}
}
