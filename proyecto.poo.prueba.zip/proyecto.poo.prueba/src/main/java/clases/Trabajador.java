package clases;

public class Trabajador {

}
