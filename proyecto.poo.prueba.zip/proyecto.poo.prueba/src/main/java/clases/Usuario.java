package clases;

public class Usuario {
	private String nombre;
	private float saldo;
	private int totalVehiculos;
	private boolean estaDeAlta;
}
