package clases;

public class Moto {

}
