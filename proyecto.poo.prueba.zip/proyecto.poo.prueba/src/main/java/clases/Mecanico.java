package clases;

public class Mecanico {

}
