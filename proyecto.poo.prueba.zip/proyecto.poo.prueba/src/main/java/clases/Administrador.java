package clases;

public class Administrador {

}
