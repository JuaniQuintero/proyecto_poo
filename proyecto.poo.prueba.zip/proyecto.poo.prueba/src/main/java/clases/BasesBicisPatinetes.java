package clases;

import java.util.ArrayList;

public class BasesBicisPatinetes {
	private String nombre;
	private ArrayList bicisYPatinetesTotales;
}
