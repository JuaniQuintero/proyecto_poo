package clases;

public class Vehiculo {

}
