package clases;

public class Patinete {

}
